import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;


public class ATM {
	private boolean userAuthenticated; // whether user is authenticated
	private int currentAccountNumber; // current user's account number
	private Screen screen; // ATM's screen
	private Keypad keypad; // ATM's keypad
	private CashDispenser cashDispenser; // ATM's cash dispenser
	private DepositSlot depositSlot; // ATM's deposit slot
	private BankDatabase bankDatabase; // account information database
	// constants corresponding to main menu options
	private static final int BALANCE_INQUIRY = 1;
	private static final int WITHDRAWAL = 2;
	private static final int DEPOSIT = 3;
	private static final int EXIT = 4;
	
	private int accountNumber;
	private int pin;
	
	private int temp;
	
	protected JTextArea jl = new JTextArea("Text"); 
	
	public static void main( String[] args ){
	new ATM().CreatJFrame("title");	
    //final ATM theATM = new ATM();
 //theATM.run();
	} // end main
	

	
	public void setJlText(String message){
		jl.setText(message);
	}
	
	public void CreatJFrame(String title){

		
		JFrame jf = new JFrame(title);
		JButton b1 = new JButton("�����˺�");
		JButton b2 = new JButton("��������");
		JButton b3 = new JButton("ѡ��");
		Container container = jf.getContentPane();
		container.setLayout(null);
		
		//JLabel jl = new JLabel();
		//jl.setText(screen);
		jl.setBounds(40,10,260,150);
		container.add(jl);
		  jl.setText("Welcome"+"\nPlease enter your account number: ");
		
		JTextField jt = new JTextField();
		jt.setBounds(100,160,180,21);
		container.add(jt);

	

		b1.setBounds(140,200,100,21);
		container.add(b1);
		b1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {	
				accountNumber = Integer.parseInt(jt.getText());
				jl.setText(jl.getText()+jt.getText()+"\nEnter your PIN: ");
				jt.setText("");
				jf.remove(b1);
				jf.repaint();
				container.add(b2);
			}
			
		});
		
		b2.setBounds(140,200,100,21);
		b2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {	
				pin = Integer.parseInt(jt.getText());
				jl.setText(jl.getText()+jt.getText()+"\nEnter your PIN: ");
				jt.setText("");
				jf.remove(b2);
				jf.repaint();
				userAuthenticated =
						  bankDatabase.authenticateUser( accountNumber, pin );
				  if ( userAuthenticated )
					 {
					  currentAccountNumber = accountNumber; // save user's account #
					  jl.setText("\nMain menu:"+"\n1 - View my balance"+"\n2 - Withdraw cash"+"\n3 - Deposit funds"+"\n4 - Exit");
					  container.add(b3);
					  } // end if
					  else
					  {
						  jl.setText("\nInvalid account number or PIN. Please try again." + "\nPlease enter your account number: ");
							container.add(b1);
					  }
					   // end method authenticateUser
			}
			
		});
		
		b3.setBounds(140,200,100,21);
		b3.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {	
				  Transaction currentTransaction = null;
				  boolean userExited = false; 
				if(Integer.parseInt(jt.getText())==1){
					  currentTransaction =
							   createTransaction( 1 );
							  currentTransaction.execute(); 
					
				}
				else if(Integer.parseInt(jt.getText())==2){
					//ʵ����û����ATM���㷨������ֻ���������Ʒ�ˡ�������
				}
				else if(Integer.parseInt(jt.getText())==3){
					
				}
				else if(Integer.parseInt(jt.getText())==4){
					
				}
				else{
					jl.setText("error!"+"\nMain menu:"+"\n1 - View my balance"+"\n2 - Withdraw cash"+"\n3 - Deposit funds"+"\n4 - Exit");
				}
				jt.setText("");
			}
			
		});

		
		container.setBackground(Color.white);
		jf.setVisible(true);
		jf.setSize(400,300);
		jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		

		
	}

	
	 // no-argument ATM constructor initializes instance variables
	 public ATM()
	 {
	 userAuthenticated = false; // user is not authenticated to start
	 currentAccountNumber = 0; // no current account number to start
	 screen = new Screen(); // create screen
	 keypad = new Keypad(); // create keypad
	 cashDispenser = new CashDispenser(); // create cash dispenser
	 depositSlot = new DepositSlot(); // create deposit slot
	 bankDatabase = new BankDatabase(); // create acct info database
	  } // end no-argument ATM constructor
	 // start ATM
	 public void run()
	  {
	  // welcome and authenticate user; perform transactions

	  while ( true )
	  {
	  // loop while user is not yet authenticated
		  
		  
	  while ( !userAuthenticated )
	  {
		  
		  jl.setText("/nWelcome");
	  
	  authenticateUser(); // authenticate user
	  } // end while
	 
	  performTransactions(); // user is now authenticated
	  userAuthenticated = false; // reset before next ATM session
	  currentAccountNumber = 0; // reset before next ATM session
	 screen.displayMessageLine( "\nThank you! Goodbye!" );
	  } // end while
	  } // end method run
	 
	  // attempts to authenticate user against database
	  private void authenticateUser()
	  {
	 
		  jl.setText( "\nPlease enter your account number: " );
	 
	  int accountNumber = temp; // input account number
	 jl.setText( "\nEnter your PIN: " ); // prompt for PIN
	  int pin = keypad.getInput(); // input PIN
	  // set userAuthenticated to boolean value returned by database
	 userAuthenticated =
	  bankDatabase.authenticateUser( accountNumber, pin );
	 
	  // check whether authentication succeeded
	  if ( userAuthenticated )
	 {
	  currentAccountNumber = accountNumber; // save user's account #
	  } // end if
	  else
	  screen.displayMessageLine(
	  "Invalid account number or PIN. Please try again." );
	  } // end method authenticateUser
	  
	  
	  
	 
	  // display the main menu and perform transactions
	  private void performTransactions()
	  {
	 // local variable to store transaction currently being processed
	  Transaction currentTransaction = null;
	  boolean userExited = false; // user has not chosen to exit
	 // loop while user has not chosen option to exit system
	   while ( !userExited )
	  {
	  // show main menu and get user selection
	  int mainMenuSelection = displayMainMenu();
	   // decide how to proceed based on user's menu selection
	   switch ( mainMenuSelection )
	   {
	  // user chose to perform one of three transaction types
	  case BALANCE_INQUIRY:
	   case WITHDRAWAL:
	  case DEPOSIT:
	   // initialize as new object of chosen type
	  currentTransaction =
	   createTransaction( mainMenuSelection );
	  currentTransaction.execute(); // execute transaction
	 break;
	   case EXIT: // user chose to terminate session
	   screen.displayMessageLine( "\nExiting the system..." );
	   userExited = true; // this ATM session should end
	   break;
	   default: // user did not enter an integer from 1-4
	   screen.displayMessageLine(
	   "\nYou did not enter a valid selection. Try again." );
	   break;
	   } // end switch
	   } // end while
	  } // end method performTransactions
	  
	   // display the main menu and return an input selection
	  private int displayMainMenu()
	   {
	   screen.displayMessageLine( "\nMain menu:" );
	   screen.displayMessageLine( "1 - View my balance" );
	   screen.displayMessageLine( "2 - Withdraw cash" );
	   screen.displayMessageLine( "3 - Deposit funds" );
	   screen.displayMessageLine( "4 - Exit\n" );
	   screen.displayMessage( "Enter a choice: " );
	   return keypad.getInput(); // return user's selection
	  } // end method displayMainMenu
	 
	  // return object of specified Transaction subclass
	  private Transaction createTransaction( int type )
	   {
	   Transaction temp = null; // temporary Transaction variable
	  switch ( type )
	  {
	   case BALANCE_INQUIRY: // create new BalanceInquiry transaction
	   temp = new BalanceInquiry(
	   currentAccountNumber, screen, bankDatabase );
	  break;
	   case WITHDRAWAL: // create new Withdrawal transaction
	   temp = new Withdrawal( currentAccountNumber, screen,
	  bankDatabase, keypad, cashDispenser );
	   break;
	   case DEPOSIT: // create new Deposit transaction
	   temp = new Deposit( currentAccountNumber, screen,
	   bankDatabase, keypad, depositSlot );
	   break;
	   } // end switch
	 
	   return temp; // return the newly created object
	   } // end method createTransaction
	   }
