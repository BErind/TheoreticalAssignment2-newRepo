/*import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class ATMCaseStudy extends JFrame
{
	//protected String screen;
	protected JLabel jl = new JLabel("Text"); 
 // main method creates and runs the ATM
	//public ATM theATM = new ATM();
	
	public static void main( String[] args ){
	new ATMCaseStudy().CreatJFrame("title");	
    //final ATM theATM = new ATM();
 //theATM.run();
	} // end main
	
	public void setJlText(String message){
		jl.setText(message);
	}
	
	public void CreatJFrame(String title){


		Screen a = new Screen();
		
		JFrame jf = new JFrame(title);
		Container container = jf.getContentPane();
		container.setLayout(null);
		
		//JLabel jl = new JLabel();
		//jl.setText(screen);
		jl.setHorizontalAlignment(SwingConstants.CENTER);
		jl.setBounds(100,10,180,84);
		container.add(jl);

	
		JButton b1 = new JButton("��½�˺�");
		b1.setBounds(140,200,100,21);
		container.add(b1);
		b1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				setJlText("123456");	
			}
			
		});

		
		container.setBackground(Color.white);
		jf.setVisible(true);
		jf.setSize(400,300);
		jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		
		//theATM.run();
		
	}
} // end class ATMCaseStudy
*/